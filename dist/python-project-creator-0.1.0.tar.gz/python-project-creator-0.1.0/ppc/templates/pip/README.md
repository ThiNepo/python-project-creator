# {{model['project']['title']}}

{{model['project']['description']}}

# Build and Upload

python setup.py sdist
python setup.py bdist_wheel

twine upload dist/\*
